// -*- mode: C++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*-
// SPDX-License-Identifier: GPL-3.0-or-later

#include <config.h>

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include <dune/common/exceptions.hh>
#include <dune/common/parallel/mpihelper.hh>

#include <dumux/common/dumuxmessage.hh>
#include <dumux/common/initialize.hh>
#include <dumux/common/parameters.hh>
#include <dumux/common/properties.hh>
#include <dumux/common/timeloop.hh>

#include <dumux/assembly/fvassembler.hh>

// This model uses an unstructured UGGrid loaded from floodmar.msh.
#include <dumux/io/grid/gridmanager_ug.hh>
#include <dumux/io/vtkoutputmodule.hh>

#include <dumux/linear/istlsolvers.hh>
#include <dumux/linear/linearalgebratraits.hh>
#include <dumux/linear/linearsolvertraits.hh>

#include <dumux/nonlinear/newtonsolver.hh>

#include "properties_reservoir_4d6d.hh"
#include "floodmarchoppednewtonsolver_restart_v4.hh"

int main(int argc, char** argv)
{
    using namespace Dumux;

    using TypeTag = Properties::TTag::TYPETAG;

    // Initialize MPI and the selected multithreading backend.
    Dumux::initialize(argc, argv);
    const auto& mpiHelper = Dune::MPIHelper::instance();

    if (mpiHelper.rank() == 0)
        DumuxMessage::print(/*firstCall=*/true);

    // Read the input file and command-line overrides.
    Parameters::init(argc, argv);

    // Read the unstructured Gmsh mesh with UGGrid.
    using Grid = GetPropType<TypeTag, Properties::Grid>;

    GridManager<Grid> gridManager;
    gridManager.init();

    const auto& leafGridView =
        gridManager.grid().leafGridView();

    if (mpiHelper.rank() == 0)
    {
        std::cout
            << "UGGrid loaded successfully: "
            << leafGridView.size(0)
            << " elements and "
            << leafGridView.size(Grid::dimension)
            << " vertices."
            << std::endl;
    }

    // Construct the axisymmetric finite-volume grid geometry.
    using GridGeometry =
        GetPropType<TypeTag, Properties::GridGeometry>;

    auto gridGeometry =
        std::make_shared<GridGeometry>(
            leafGridView
        );

    // Create the problem containing initial and boundary conditions.
    using Problem =
        GetPropType<TypeTag, Properties::Problem>;

    auto problem =
        std::make_shared<Problem>(
            gridGeometry
        );

    using Scalar =
        GetPropType<TypeTag, Properties::Scalar>;

    // Initialize the solution vector, optionally replacing the analytical
    // initial condition with a cell-centred FloodMAR restart state.
    using SolutionVector =
        GetPropType<TypeTag, Properties::SolutionVector>;

    SolutionVector x;
    problem->applyInitialSolution(x);

    Scalar startTime = 0.0;
    const bool restartEnabled =
        getParam<bool>("Restart.Enable", false);

    if (restartEnabled)
    {
        const std::string restartFile =
            getParam<std::string>("Restart.File");
        std::ifstream input(restartFile);
        if (!input)
            throw std::runtime_error(
                "Could not open FloodMAR restart file: " + restartFile);

        std::string magic;
        std::size_t numDofs = 0;
        input >> magic >> numDofs >> startTime;

        if (magic != "FLOODMAR_RESTART_V1")
            throw std::runtime_error(
                "Unsupported FloodMAR restart format in: " + restartFile);
        if (numDofs != x.size())
            throw std::runtime_error(
                "Restart DOF count does not match the current grid");

        std::vector<bool> seen(numDofs, false);
        for (std::size_t row = 0; row < numDofs; ++row)
        {
            std::size_t dofIdx = 0;
            int phaseState = 0;
            Scalar pressure = 0.0;
            Scalar switchValue = 0.0;
            Scalar oxygen = 0.0;

            if (!(input
                  >> dofIdx
                  >> phaseState
                  >> pressure
                  >> switchValue
                  >> oxygen))
                throw std::runtime_error(
                    "Restart file ended before all DOFs were read");

            if (dofIdx >= numDofs || seen[dofIdx])
                throw std::runtime_error(
                    "Restart file contains an invalid or duplicate DOF index");

            x[dofIdx].setState(phaseState);
            x[dofIdx][0] = pressure;
            x[dofIdx][1] = switchValue;
            x[dofIdx][2] = oxygen;
            seen[dofIdx] = true;
        }

        std::size_t extraDof = 0;
        if (input >> extraDof)
            throw std::runtime_error(
                "Restart file contains more rows than the current grid");

        problem->setTime(startTime);

        if (mpiHelper.rank() == 0)
            std::cout
                << "Loaded FloodMAR restart: " << restartFile
                << "\nRestart time = " << startTime
                << " s (" << startTime/3600.0 << " h)"
                << std::endl;
    }

    auto xOld = x;

    // Initialize volume and flux variables.
    using GridVariables =
        GetPropType<TypeTag, Properties::GridVariables>;

    auto gridVariables =
        std::make_shared<GridVariables>(
            problem,
            gridGeometry
        );

    gridVariables->init(x);

    // Configure VTK output for ParaView.
    VtkOutputModule<GridVariables, SolutionVector>
        vtkWriter(
            *gridVariables,
            x,
            problem->name()
        );

    using VelocityOutput =
        GetPropType<TypeTag, Properties::VelocityOutput>;

    vtkWriter.addVelocityOutput(
        std::make_shared<VelocityOutput>(
            *gridVariables
        )
    );

    GetPropType<
        TypeTag,
        Properties::IOFields
    >::initOutputModule(vtkWriter);

    // Write the loaded or analytical initial state under the new run name.
    vtkWriter.write(startTime);

    // Read time-loop parameters. DuMuX uses seconds here.
    const Scalar tEnd =
        getParam<Scalar>(
            "TimeLoop.TEnd"
        );

    const Scalar dtInitial =
        getParam<Scalar>(
            "TimeLoop.DtInitial"
        );

    const Scalar maxDt =
        getParam<Scalar>(
            "TimeLoop.MaxTimeStepSize"
        );

    const Scalar outputInterval =
        getParam<Scalar>(
            "TimeLoop.OutputInterval",
            21600.0
        );

    auto timeLoop =
        std::make_shared<TimeLoop<Scalar>>(
            startTime,
            dtInitial,
            tEnd
        );

    timeLoop->setMaxTimeStepSize(maxDt);

    // Let the problem read the currently attempted implicit time level.
    // This remains correct when the Newton solver internally reduces dt and
    // retries the same step.
    problem->setTimeLoop(timeLoop);

    // Create the finite-volume assembler.
    using Assembler =
        FVAssembler<TypeTag, DiffMethod::numeric>;

    auto assembler =
        std::make_shared<Assembler>(
            problem,
            gridGeometry,
            gridVariables,
            timeLoop,
            xOld
        );

    // Create the sequential UMFPack direct linear solver.
    using LinearSolver =
        UMFPackIstlSolver<
            LinearSolverTraits<GridGeometry>,
            LinearAlgebraTraitsFromAssembler<Assembler>
        >;

    auto linearSolver =
        std::make_shared<LinearSolver>();

    // Create the nonlinear Newton solver.
    using NonlinearSolver =
        FloodMarChoppedNewtonSolver<Assembler, LinearSolver>;

    NonlinearSolver nonlinearSolver(
        assembler,
        linearSolver
    );

    Scalar nextOutputTime =
        startTime + outputInterval;

    timeLoop->start();

    std::ofstream reservoirHistory(
        problem->name()
        + "_reservoir_history.csv"
    );

    reservoirHistory
        << "time_h,reservoir_head_cm,"
        << "reservoir_storage_m3,"
        << "reservoir_net_flux_m3_s\n";

    reservoirHistory
        << std::setprecision(15);


    do
    {
        // Never step across a change point in the time-variable drywell
        // boundary. This makes the 5-hour linear ramps reproducible.
        const Scalar nextBoundaryEvent =
            problem->nextBoundaryEventTime(timeLoop->time());
        if (nextBoundaryEvent < timeLoop->time() + timeLoop->timeStepSize())
        {
            timeLoop->setTimeStepSize(
                nextBoundaryEvent - timeLoop->time()
            );
        }

        // Solve the nonlinear two-phase system.
        nonlinearSolver.solve(
            x,
            *timeLoop
        );

        // The Newton solver may have reduced dt internally.
        // Use the actually accepted dt/end time.
        const Scalar acceptedDt =
            timeLoop->timeStepSize();

        const Scalar acceptedEndTime =
            timeLoop->time()
            + acceptedDt;

        problem->updateReservoirAfterAcceptedStep(
            *gridVariables,
            x,
            acceptedEndTime,
            acceptedDt
        );

        // Accept the new solution.
        xOld = x;
        gridVariables->advanceTimeStep();

        // Advance simulation time.
        timeLoop->advanceTimeStep();
        timeLoop->reportTimeStep();

        if (timeLoop->time() >= 95.0*3600.0)
        {
            reservoirHistory
                << timeLoop->time()/3600.0 << ","
                << problem->reservoirHeadCm() << ","
                << problem->reservoirStorageM3() << ","
                << problem->lastReservoirNetFluxM3s()
                << "\n";

            reservoirHistory.flush();
        }

        // Write output at the specified interval and final time.
        const Scalar timeTolerance =
            1.0e-8
            * std::max(
                Scalar(1.0),
                timeLoop->time()
            );

        if (
            timeLoop->time()
                >= nextOutputTime - timeTolerance
            || timeLoop->finished()
        )
        {
            vtkWriter.write(
                timeLoop->time()
            );

            while (
                nextOutputTime
                <= timeLoop->time()
                    + timeTolerance
            )
            {
                nextOutputTime +=
                    outputInterval;
            }
        }

        // Use the Newton solver's suggested next time step,
        // but do not exceed the configured maximum.
        const Scalar suggestedDt =
            nonlinearSolver.suggestTimeStepSize(
                timeLoop->timeStepSize()
            );

        timeLoop->setTimeStepSize(
            std::min(
                maxDt,
                suggestedDt
            )
        );

    } while (!timeLoop->finished());

    timeLoop->finalize(
        leafGridView.comm()
    );

    if (mpiHelper.rank() == 0)
    {
        Parameters::print();
        DumuxMessage::print(/*firstCall=*/false);
    }

    return 0;
}
