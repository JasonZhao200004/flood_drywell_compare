#ifndef DUMUX_FLOOD_MAR_PROBLEM_HH
#define DUMUX_FLOOD_MAR_PROBLEM_HH

#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include <dumux/common/properties.hh>
#include <dumux/common/parameters.hh>
#include <dumux/common/boundarytypes.hh>
#include <dumux/common/numeqvector.hh>
#include <dumux/porousmediumflow/problem.hh>
#include <dumux/material/binarycoefficients/h2o_o2.hh>

namespace Dumux {

template<class TypeTag>
class WaterAirProblem
: public PorousMediumFlowProblem<TypeTag>
{
    using ParentType = PorousMediumFlowProblem<TypeTag>;

    using Scalar = GetPropType<TypeTag, Properties::Scalar>;
    using GridGeometry = GetPropType<TypeTag, Properties::GridGeometry>;
    using GridView = typename GridGeometry::GridView;
    using FVElementGeometry = typename GridGeometry::LocalView;
    using SubControlVolume = typename FVElementGeometry::SubControlVolume;
    using SubControlVolumeFace = typename FVElementGeometry::SubControlVolumeFace;
    using FluidSystem = GetPropType<TypeTag, Properties::FluidSystem>;
    using ModelTraits = GetPropType<TypeTag, Properties::ModelTraits>;
    using Indices = typename ModelTraits::Indices;

    enum
    {
        pressureIdx = Indices::pressureIdx,
        switchIdx = Indices::switchIdx,
        oxygenIdx = Indices::switchIdx + 1
    };

    enum
    {
        wPhaseOnly = Indices::firstPhaseOnly,
        bothPhases = Indices::bothPhases
    };

    using PrimaryVariables = GetPropType<TypeTag, Properties::PrimaryVariables>;
    using NumEqVector = Dumux::NumEqVector<PrimaryVariables>;
    using BoundaryTypes = Dumux::BoundaryTypes<ModelTraits::numEq()>;
    using Element = typename GridView::template Codim<0>::Entity;
    using GlobalPosition = typename Element::Geometry::GlobalCoordinate;

public:
    WaterAirProblem(std::shared_ptr<const GridGeometry> gridGeometry)
    : ParentType(gridGeometry)
    , atmosphericOxygenDiffusionCoefficient_(
        getParam<Scalar>(
            "Problem.AtmosphericOxygenDiffusionCoefficient",
            getParam<Scalar>("Problem.AtmosphericGasTransferCoefficient", 1.0e-6)
        )
      )
    , atmosphericGasPressureFactor_(
        getParam<Scalar>("Problem.AtmosphericGasPressureFactor", 1.0)
      )
    , drywellStartupRampTime_(
        getParam<Scalar>("Problem.DrywellStartupRampTime", 3600.0)
      )
    , drywellInjectionHeadCm_(
        getParam<Scalar>("Problem.DrywellInjectionHead", 1200.0)
      )
    , initialOxygenProfileFile_(
        getParam<std::string>(
            "Problem.InitialOxygenProfileFile",
            "oxygen_initial_2880.dat"
        )
      )
    {
        FluidSystem::init();
        name_ = getParam<std::string>("Problem.Name", "floodmar");
        readInitialOxygenProfile_();

        std::cout << "Flood-MAR axisymmetric water-N2-O2 model\n"
                  << "Open atmospheric gas-pressure boundary\n"
                  << "O2 surface diffusion coefficient = "
                  << atmosphericOxygenDiffusionCoefficient_ << " m/s\n"
                  << "Gas-pressure transmissibility factor = "
                  << atmosphericGasPressureFactor_ << "\n"
                  << "Drywell startup ramp time = "
                  << drywellStartupRampTime_ << " s\n"
                  << "Drywell injection head = "
                  << drywellInjectionHeadCm_ << " cm\n"
                  << "Initial O2 profile = "
                  << initialOxygenProfileFile_ << "\n"
                  << "Formal drywell simulation: 3 cycles, 720 h"
                  << std::endl;
    }

    const std::string& name() const
    { return name_; }

    Scalar temperatureAtPos(const GlobalPosition&) const
    { return 298.15; }

    void setTime(Scalar time)
    { time_ = time; }

    Scalar nextBoundaryEventTime(Scalar currentTimeSeconds) const
    {
        static constexpr std::array<Scalar, 12> eventHours = {
            0.0, 96.0, 101.0, 240.0, 245.0, 336.0,
            341.0, 480.0, 485.0, 576.0, 581.0, 720.0
        };

        for (const Scalar eventHour : eventHours)
        {
            const Scalar eventTime = eventHour*3600.0;
            if (eventTime > currentTimeSeconds + 1.0e-8)
                return eventTime;
        }
        return std::numeric_limits<Scalar>::infinity();
    }

    BoundaryTypes boundaryTypesAtPos(const GlobalPosition& globalPos) const
    {
        BoundaryTypes bcTypes;
        bcTypes.setAllNeumann();

        return bcTypes;
    }

    PrimaryVariables dirichletAtPos(const GlobalPosition& globalPos) const
    {
        if (isVariHeadBoundary_(globalPos))
            return drywellState_(globalPos);

        return initial_(globalPos);
    }

    template<class ElementVolumeVariables, class ElementFluxVariablesCache>
    NumEqVector neumann(const Element&,
                        const FVElementGeometry& fvGeometry,
                        const ElementVolumeVariables& elemVolVars,
                        const ElementFluxVariablesCache&,
                        const SubControlVolumeFace& scvf) const
    {
        NumEqVector values(0.0);
        const auto& globalPos = scvf.ipGlobal();
        const auto& volVars = elemVolVars[scvf.insideScvIdx()];

        if (isAtmosphere_(globalPos))
        {
            const int gasPhaseIdx = FluidSystem::gasPhaseIdx;
            constexpr Scalar atmosphericPressure = 1.0e5;
            constexpr Scalar temperature = 298.15;
            constexpr Scalar gasConstant = 8.31446261815324;
            constexpr Scalar atmosphericWaterVaporPressure = 3169.0;

            const Scalar cO2Atmosphere =
                atmosphericOxygenMassConcentration_
                /FluidSystem::molarMass(FluidSystem::O2Idx);

            const Scalar cH2OAtmosphere =
                atmosphericWaterVaporPressure
                /(gasConstant*temperature);

            const Scalar cDryAtmosphere =
                (atmosphericPressure - atmosphericWaterVaporPressure)
                /(gasConstant*temperature);

            const Scalar cN2Atmosphere =
                std::max(Scalar(0.0), cDryAtmosphere - cO2Atmosphere);

            const Scalar gasMolarDensity = volVars.molarDensity(gasPhaseIdx);
            const Scalar xH2OSoil =
                volVars.moleFraction(gasPhaseIdx, FluidSystem::H2OIdx);
            const Scalar xO2Soil =
                volVars.moleFraction(gasPhaseIdx, FluidSystem::O2Idx);
            const Scalar xN2Soil =
                volVars.moleFraction(gasPhaseIdx, FluidSystem::N2Idx);
            const Scalar cO2Soil = gasMolarDensity*xO2Soil;

            // Outward Darcy gas volume flux [m/s]. Positive values vent
            // soil gas; negative values draw atmospheric gas into the soil.
            const auto& insideScv = fvGeometry.scv(scvf.insideScvIdx());
            const Scalar distance =
                (insideScv.center() - globalPos).two_norm();

            const Scalar gasVolumeFlux =
                atmosphericGasPressureFactor_
                *volVars.permeability()
                *volVars.mobility(gasPhaseIdx)
                *(volVars.pressure(gasPhaseIdx) - atmosphericPressure)
                /distance;

            Scalar advectiveH2OFlux = 0.0;
            Scalar advectiveN2Flux = 0.0;
            Scalar advectiveO2Flux = 0.0;

            if (gasVolumeFlux >= 0.0)
            {
                // Gas leaving the domain carries the local soil composition.
                advectiveH2OFlux =
                    gasVolumeFlux*gasMolarDensity*xH2OSoil;
                advectiveN2Flux =
                    gasVolumeFlux*gasMolarDensity*xN2Soil;
                advectiveO2Flux =
                    gasVolumeFlux*gasMolarDensity*xO2Soil;
            }
            else
            {
                // Gas entering the domain carries the complete atmospheric
                // H2O-N2-O2 composition at 25 degrees Celsius.
                advectiveH2OFlux = gasVolumeFlux*cH2OAtmosphere;
                advectiveN2Flux = gasVolumeFlux*cN2Atmosphere;
                advectiveO2Flux = gasVolumeFlux*cO2Atmosphere;
            }

            // Molecular O2 exchange with the atmospheric reservoir.
            // Positive is outward according to the DuMuX Neumann convention.
            const Scalar diffusiveO2Flux =
                atmosphericOxygenDiffusionCoefficient_
                *(cO2Soil - cO2Atmosphere);

            values[Indices::conti0EqIdx + FluidSystem::H2OIdx] =
                advectiveH2OFlux;
            values[Indices::conti0EqIdx + FluidSystem::N2Idx] =
                advectiveN2Flux;
            values[Indices::conti0EqIdx + FluidSystem::O2Idx] =
                advectiveO2Flux + diffusiveO2Flux;

            // There is no imposed liquid rainfall or evaporation flux. The
            // H2O flux above is only the water vapor transported with the
            // pressure-driven gas mixture.
        }
        else if (isVariHeadBoundary_(globalPos))
        {
            // CCTpfa requires a pure boundary type on each boundary face.
            // Therefore, impose the variable hydraulic head as a Robin flux
            // for all component balances. This is the flux equivalent of the
            // former pressure/state Dirichlet condition, while retaining the
            // HYDRUS third-type oxygen condition.
            const int liquidPhaseIdx = FluidSystem::liquidPhaseIdx;
            const Scalar density = volVars.density(liquidPhaseIdx);
            const Scalar molarDensity = volVars.molarDensity(liquidPhaseIdx);
            const Scalar mobility = volVars.mobility(liquidPhaseIdx);
            const auto permeability = volVars.permeability();

            constexpr Scalar waterDensity = 1000.0;
            constexpr Scalar gravity = 9.81;
            constexpr Scalar atmosphericPressure = 1.0e5;

            // During startup, ramp the water level/head itself instead of
            // activating the complete drywell wall immediately and merely
            // scaling its flux. This makes the wetted boundary grow upward
            // from the drywell bottom and avoids a simultaneous phase switch
            // along the full 12 m injection interval.
            const Scalar startupFactor =
                drywellStartupRampTime_ > 0.0
                ? std::clamp(time_/drywellStartupRampTime_, Scalar(0.0), Scalar(1.0))
                : Scalar(1.0);

            const Scalar scheduledDrywellHeadCm = drywellHeadCm_(time_);
            const Scalar rampedDrywellHeadCm =
                scheduledDrywellHeadCm > 0.0
                ? startupFactor*scheduledDrywellHeadCm
                : scheduledDrywellHeadCm;

            // HYDRUS Var H-1 is the pressure head at the lowest point of
            // the drywell (y = 14 m), not a spatially uniform pressure head
            // along the complete vertical wall.  The hydrostatic pressure
            // head therefore decreases by one metre per metre of elevation.
            // Example: H_bottom = 450 cm gives a water surface at
            // y = 14 + 4.5 = 18.5 m (11.5 m below the ground surface).
            const Scalar localDrywellHeadCm =
                rampedDrywellHeadCm
                - (globalPos[1] - drywellBottomElevation_)*100.0;

            const Scalar boundaryLiquidPressure =
                atmosphericPressure
                + waterDensity*gravity*(localDrywellHeadCm/100.0);

            const auto& insideScv = fvGeometry.scv(scvf.insideScvIdx());
            const Scalar distance =
                (insideScv.center() - globalPos).two_norm();
            const auto normal = scvf.unitOuterNormal();

            // HYDRUS option: "Atmospheric BC when the specified nodal
            // pressure head is negative".  Rainfall and evaporation are
            // both zero here, hence the exposed part above the instantaneous
            // drywell water level has no imposed liquid-water flux.
            const Scalar liquidVolumeFlux =
                localDrywellHeadCm > 0.0
                ? permeability*mobility
                    *((volVars.pressure(liquidPhaseIdx)
                       - boundaryLiquidPressure)/distance
                      - density*gravity*normal[1])
                : Scalar(0.0);

            std::array<Scalar, FluidSystem::numComponents>
                componentMolarConcentration{};

            if (liquidVolumeFlux >= 0.0)
            {
                // Water leaving the domain carries the complete local liquid
                // composition, including dissolved N2 and O2.
                for (int compIdx = 0;
                     compIdx < FluidSystem::numComponents;
                     ++compIdx)
                {
                    componentMolarConcentration[compIdx] =
                        molarDensity
                        *volVars.moleFraction(liquidPhaseIdx, compIdx);
                }
            }
            else
            {
                // Inflow carries HYDRUS cValue2 = 8e-6 g/cm3
                // = 0.008 kg/m3. Incoming water contains no imposed N2;
                // the remaining liquid molar concentration is H2O.
                const Scalar oxygenMolarConcentration =
                    drywellInfluentOxygenMassConcentration_
                    /FluidSystem::molarMass(FluidSystem::O2Idx);

                componentMolarConcentration[FluidSystem::O2Idx] =
                    oxygenMolarConcentration;
                componentMolarConcentration[FluidSystem::N2Idx] = 0.0;
                componentMolarConcentration[FluidSystem::H2OIdx] =
                    std::max(
                        Scalar(0.0),
                        molarDensity - oxygenMolarConcentration
                    );
            }

            for (int compIdx = 0;
                 compIdx < FluidSystem::numComponents;
                 ++compIdx)
            {
                values[Indices::conti0EqIdx + compIdx] =
                    liquidVolumeFlux
                    *componentMolarConcentration[compIdx];
            }
        }
        else if (isBottom_(globalPos))
        {
            constexpr Scalar gravity = 9.81;
            const int liquidPhaseIdx = FluidSystem::liquidPhaseIdx;

            const Scalar density = volVars.density(liquidPhaseIdx);
            const Scalar molarDensity = volVars.molarDensity(liquidPhaseIdx);
            const Scalar mobility = volVars.mobility(liquidPhaseIdx);
            const auto permeability = volVars.permeability();

            // Free drainage: unit hydraulic gradient.
            const Scalar liquidVolumeFlux =
                permeability*mobility*density*gravity;

            for (int compIdx = 0;
                 compIdx < FluidSystem::numComponents;
                 ++compIdx)
            {
                values[Indices::conti0EqIdx + compIdx] =
                    liquidVolumeFlux
                    *molarDensity
                    *volVars.moleFraction(liquidPhaseIdx, compIdx);
            }
        }

        return values;
    }

    PrimaryVariables initialAtPos(const GlobalPosition& globalPos) const
    { return initial_(globalPos); }

    template<class ElementVolumeVariables>
    NumEqVector source(const Element&,
                       const FVElementGeometry&,
                       const ElementVolumeVariables& elemVolVars,
                       const SubControlVolume& scv) const
    {
        NumEqVector values(0.0);
        const auto& volVars = elemVolVars[scv];
        const int liquidPhaseIdx = FluidSystem::liquidPhaseIdx;
        const int gasPhaseIdx = FluidSystem::gasPhaseIdx;

        const Scalar porosity = volVars.porosity();
        const Scalar liquidSaturation = volVars.saturation(liquidPhaseIdx);
        const Scalar gasSaturation = volVars.saturation(gasPhaseIdx);
        const Scalar waterContent = porosity*liquidSaturation;
        const Scalar moistureFactor = moistureDecayFactor_(waterContent);

        constexpr Scalar oxygenRegularization = 1.0e-12;
        const auto regularizedOxygenMoleFraction =
            [=](Scalar x)
            {
                const Scalar ratio = x/oxygenRegularization;
                return x*(Scalar(1.0) - std::exp(-ratio*ratio));
            };

        const Scalar xO2Liquid = regularizedOxygenMoleFraction(
            volVars.moleFraction(liquidPhaseIdx, FluidSystem::O2Idx));
        const Scalar xO2Gas = regularizedOxygenMoleFraction(
            volVars.moleFraction(gasPhaseIdx, FluidSystem::O2Idx));

        const Scalar liquidOxygenInventory =
            porosity*liquidSaturation
            *volVars.molarDensity(liquidPhaseIdx)*xO2Liquid;
        const Scalar gasOxygenInventory =
            porosity*gasSaturation
            *volVars.molarDensity(gasPhaseIdx)*xO2Gas;

        // HYDRUS first-order constants, converted from 1/h to 1/s.
        constexpr Scalar liquidDecayRate = 0.06/3600.0;
        constexpr Scalar gasDecayRate = 0.002/3600.0;

        values[Indices::conti0EqIdx + FluidSystem::O2Idx] =
            -moistureFactor
            *(liquidDecayRate*liquidOxygenInventory
              + gasDecayRate*gasOxygenInventory);

        return values;
    }

private:
    static Scalar liquidMoleFractionFromLiquidMassConcentration_(Scalar c)
    {
        constexpr Scalar waterDensity = 1000.0;
        const Scalar oxygenMolarConcentration =
            c/FluidSystem::molarMass(FluidSystem::O2Idx);
        const Scalar waterMolarConcentration =
            waterDensity/FluidSystem::molarMass(FluidSystem::H2OIdx);
        return oxygenMolarConcentration
               /(waterMolarConcentration + oxygenMolarConcentration);
    }

    static Scalar moistureDecayFactor_(Scalar theta)
    {
        constexpr Scalar minimumDryRate = 0.1;
        constexpr Scalar theta0 = 0.06;
        constexpr Scalar theta1 = 0.15;
        constexpr Scalar theta2 = 0.25;
        constexpr Scalar theta3 = 0.37;
        constexpr Scalar minimumWetRate = 0.3;

        if (theta <= theta0) return minimumDryRate;
        if (theta < theta1)
        {
            const Scalar f = (theta - theta0)/(theta1 - theta0);
            return minimumDryRate + f*(1.0 - minimumDryRate);
        }
        if (theta <= theta2) return 1.0;
        if (theta < theta3)
        {
            const Scalar f = (theta - theta2)/(theta3 - theta2);
            return 1.0 + f*(minimumWetRate - 1.0);
        }
        return minimumWetRate;
    }

    PrimaryVariables initial_(const GlobalPosition& globalPos) const
    {
        const Scalar depthCm = (30.0 - globalPos[1])*100.0;
        Scalar headCm = -55.0;

        if (depthCm <= 1750.0)
            headCm = -55.0 + depthCm/1750.0*30.0;
        else if (depthCm <= 2090.0)
            headCm = -25.0
                     + (depthCm - 1750.0)/(2090.0 - 1750.0)*(-125.0);
        else
            headCm = -150.0
                     + (depthCm - 2090.0)/(3000.0 - 2090.0)*50.0;

        return stateFromHead_(
            globalPos,
            headCm,
            liquidMoleFractionFromLiquidMassConcentration_(
                initialOxygenMassConcentrationAtElevation_(globalPos[1]))
        );
    }

    void readInitialOxygenProfile_()
    {
        std::ifstream input(initialOxygenProfileFile_);
        if (!input)
            throw std::runtime_error(
                "Cannot open initial oxygen profile: "
                + initialOxygenProfileFile_
            );

        Scalar elevation = 0.0;
        Scalar concentrationGPerCm3 = 0.0;
        while (input >> elevation >> concentrationGPerCm3)
        {
            oxygenProfileElevation_.push_back(elevation);
            // 1 g/cm3 = 1000 kg/m3.
            oxygenProfileMassConcentration_.push_back(
                concentrationGPerCm3*1000.0
            );
        }

        if (oxygenProfileElevation_.size() < 2)
            throw std::runtime_error(
                "Initial oxygen profile must contain at least two rows"
            );

        if (!std::is_sorted(
                oxygenProfileElevation_.begin(),
                oxygenProfileElevation_.end()))
            throw std::runtime_error(
                "Initial oxygen profile elevations must be increasing"
            );
    }

    Scalar initialOxygenMassConcentrationAtElevation_(Scalar elevation) const
    {
        if (elevation <= oxygenProfileElevation_.front())
            return oxygenProfileMassConcentration_.front();
        if (elevation >= oxygenProfileElevation_.back())
            return oxygenProfileMassConcentration_.back();

        const auto upper = std::upper_bound(
            oxygenProfileElevation_.begin(),
            oxygenProfileElevation_.end(),
            elevation
        );
        const std::size_t i1 =
            std::distance(oxygenProfileElevation_.begin(), upper);
        const std::size_t i0 = i1 - 1;
        const Scalar fraction =
            (elevation - oxygenProfileElevation_[i0])
            /(oxygenProfileElevation_[i1]
              - oxygenProfileElevation_[i0]);

        return oxygenProfileMassConcentration_[i0]
            + fraction
              *(oxygenProfileMassConcentration_[i1]
                - oxygenProfileMassConcentration_[i0]);
    }

    PrimaryVariables stateFromHead_(const GlobalPosition& globalPos,
                                    Scalar headCm,
                                    Scalar liquidOxygenMoleFraction) const
    {
        PrimaryVariables priVars(0.0);
        constexpr Scalar atmosphericPressure = 1.0e5;
        constexpr Scalar waterDensity = 1000.0;
        constexpr Scalar gravity = 9.81;

        const Scalar liquidPressure =
            atmosphericPressure
            + waterDensity*gravity*(headCm/100.0);

        if (headCm >= 0.0)
        {
            priVars.setState(wPhaseOnly);
            priVars[pressureIdx] = liquidPressure;
            priVars[switchIdx] = 0.0;
            priVars[oxygenIdx] = liquidOxygenMoleFraction;
        }
        else
        {
            const Scalar capillaryPressure =
                atmosphericPressure - liquidPressure;
            const auto interaction =
                this->spatialParams().fluidMatrixInteractionAtPos(globalPos);
            Scalar liquidSaturation = interaction.sw(capillaryPressure);
            liquidSaturation = std::clamp(
                liquidSaturation, Scalar(0.0), Scalar(1.0));

            priVars.setState(bothPhases);
            priVars[pressureIdx] = liquidPressure;
            priVars[switchIdx] = 1.0 - liquidSaturation;
            priVars[oxygenIdx] = liquidOxygenMoleFraction;
        }

        return priVars;
    }

    PrimaryVariables drywellState_(const GlobalPosition& globalPos) const
    {
        return stateFromHead_(
            globalPos,
            drywellHeadCm_(time_),
            liquidMoleFractionFromLiquidMassConcentration_(
                initialOxygenMassConcentrationAtElevation_(globalPos[1])
            )
        );
    }

    Scalar drywellHeadCm_(Scalar timeSeconds) const
    {
        const Scalar timeHours = timeSeconds/3600.0;
        static constexpr std::array<Scalar, 12> times = {
            0.0, 96.0, 101.0, 240.0, 245.0, 336.0,
            341.0, 480.0, 485.0, 576.0, 581.0, 720.0
        };
        const std::array<Scalar, 12> heads = {
            drywellInjectionHeadCm_, drywellInjectionHeadCm_, -25.0, -25.0,
            drywellInjectionHeadCm_, drywellInjectionHeadCm_, -25.0, -25.0,
            drywellInjectionHeadCm_, drywellInjectionHeadCm_, -25.0, -25.0
        };

        if (timeHours <= times.front()) return heads.front();
        if (timeHours >= times.back()) return heads.back();

        for (std::size_t i = 0; i + 1 < times.size(); ++i)
        {
            if (timeHours >= times[i] && timeHours <= times[i + 1])
            {
                const Scalar f =
                    (timeHours - times[i])/(times[i + 1] - times[i]);
                return heads[i] + f*(heads[i + 1] - heads[i]);
            }
        }
        return heads.back();
    }

    bool isAtmosphere_(const GlobalPosition& globalPos) const
    { return globalPos[1] > 30.0 - eps_; }

    bool isBottom_(const GlobalPosition& globalPos) const
    { return globalPos[1] < eps_; }

    bool isVariHeadBoundary_(const GlobalPosition& globalPos) const
    {
        const Scalar x = globalPos[0];
        const Scalar y = globalPos[1];

        const bool mainWall =
            std::abs(x - 0.61) < eps_
            && y >= 14.0 - eps_ && y <= 27.0 + eps_;
        const bool wellBottom =
            std::abs(y - 14.0) < eps_ && x <= 0.61 + eps_;

        // Match the blue HYDRUS VariHead boundary: the complete lower
        // 1.22 m-diameter section, i.e. both its vertical wall and bottom.
        // The upper black 1.23 m-diameter casing wall (ground to 3 m depth)
        // and its 5 mm radial shoulder are intentionally no-flow.
        return mainWall || wellBottom;
    }

    static constexpr Scalar eps_ = 1.0e-6;
    static constexpr Scalar drywellBottomElevation_ = 14.0;
    Scalar time_ = 0.0;
    std::string name_;
    Scalar atmosphericOxygenDiffusionCoefficient_;
    Scalar atmosphericGasPressureFactor_;
    Scalar drywellStartupRampTime_;
    Scalar drywellInjectionHeadCm_;

    std::string initialOxygenProfileFile_;
    std::vector<Scalar> oxygenProfileElevation_;
    std::vector<Scalar> oxygenProfileMassConcentration_;

    // HYDRUS cValue2: 8e-6 g/cm3 = 0.008 kg/m3 inflowing water.
    static constexpr Scalar drywellInfluentOxygenMassConcentration_ = 0.008;
    // 0.000261 g/cm3 = 0.261 kg/m3 gas.
    static constexpr Scalar atmosphericOxygenMassConcentration_ = 0.261;
};

} // namespace Dumux

#endif
